
          window.__NEXT_REGISTER_PAGE('/job', function() {
            var comp = module.exports=webpackJsonp([16],{312:function(e,t,l){e.exports=l(313)},313:function(e,t,l){"use strict";function r(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(t,"__esModule",{value:!0});var n=l(0),a=function(e){if(e&&e.__esModule)return e;var t={};if(null!=e)for(var l in e)Object.prototype.hasOwnProperty.call(e,l)&&(t[l]=e[l]);return t.default=e,t}(n),c=l(12),u=r(c),o=l(24),i=r(o),s=function(){return a.createElement(u.default,null,a.createElement("div",{className:"article"},a.createElement("header",{className:"article__header"},a.createElement("h1",{className:"article__title"},"Работа")),a.createElement("section",{className:"article__body"},a.createElement("p",null,"Раздел находится в стадии наполнения."))))};/*!
    * Dependencies
    */
t.default=function(){return a.createElement(i.default,null,a.createElement(s,null))}}},[312]);
            return { page: comp.default }
          })
        